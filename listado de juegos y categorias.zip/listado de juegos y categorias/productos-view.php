<div class="container"><!--contenedor general-->
  <div class="row">
      <div class="col-sm-12">
          <!-- Nav tabs -->
        <ul class="nav nav-tabs">
          <li class="active"><a href="#all_categori" data-toggle="tab"><i class="fa fa-bars"></i>&nbsp;&nbsp;Todas las categorías</a></li>
          <li><a href="#accion" data-toggle="tab"><i class="fa fa-desktop"></i>&nbsp;&nbsp;ACCION</a></li>
          <li><a href="#deportivo" data-toggle="tab"><i class="fa fa-laptop"></i>&nbsp;&nbsp;DEPORTIVOS</a></li>
   
        </ul>

        <!-- Tab panes -->
        <div class="tab-content">
            <br>
            <!--******Todas****-->
            <div class="tab-pane active" id="all_categori">
                  <div class="col-sm-4">
                    <div class="thumbnail text-center">
                      <img class="img-thumbnail img-responsive" src="img/prod/fifa.jpg" alt="Image">
                      <div class="caption">
                        <h3 class="text-danger">FIFA</h3>
                        <p class="text-primary">DEPORTIVO<br>9.6</p>
                        <p><button type="button" class="btn btn-success btn-sm">Más info</button></p>
                      </div>
                    </div>
                  </div>

                  <div class="col-sm-4">
                    <div class="thumbnail text-center">
                      <img class="img-thumbnail img-responsive" src="img/prod/prototype.jpg" alt="Image">
                      <div class="caption">
                        <h3 class="text-danger">Prototype</h3>
                        <p class="text-primary">ACCION<br> 10/10</p>
                        <p><button type="button" class="btn btn-success btn-sm">Más info</button></p>
                      </div>
                    </div>
                  </div>

                  <div class="col-sm-4">
                    <div class="thumbnail text-center">
                      <img class="img-thumbnail img-responsive" src="img/prod/mw3.jpg" alt="Image">
                      <div class="caption">
                        <h3 class="text-danger">CALL OF DUTY MW3</h3>
                        <p class="text-primary">FPS<br>10 DE 10</p>
                        <p><button type="button" class="btn btn-success btn-sm">Más info</button></p>
                      </div>
                    </div>
                  </div>

                  <div class="col-sm-4">
                    <div class="thumbnail text-center">
                      <img class="img-thumbnail img-responsive" src="img/prod/pes.jpg" alt="Image">
                      <div class="caption">
                        <h3 class="text-danger">PES</h3>
                        <p class="text-primary">9 DE 10 <br>DEPORTIVO</p>
                        <p><button type="button" class="btn btn-success btn-sm">Más info</button></p>
                      </div>
                    </div>
                  </div>

                  <div class="col-sm-4">
                    <div class="thumbnail text-center">
                      <img class="img-thumbnail img-responsive" src="img/prod/gta.jpg" alt="Image">
                      <div class="caption">
                        <h3 class="text-danger">GTA V</h3>
                        <p class="text-primary">8 DE 10<br>ACCION</p>
                        <p><button type="button" class="btn btn-success btn-sm">Más info</button></p>
                      </div>
                    </div>
                  </div>

                  <div class="col-sm-4">
                    <div class="thumbnail text-center">
                      <img class="img-thumbnail img-responsive" src="img/prod/mlb.jpg" alt="Image">
                      <div class="caption">
                        <h3 class="text-danger">MLB THE SHOW</h3>
                        <p class="text-primary">10 DE 10<br>DEPORTIVOS</p>
                        <p><button type="button" class="btn btn-success btn-sm">Más info</button></p>
                      </div>
                    </div>
                  </div>

                  <div class="col-sm-4">
                    <div class="thumbnail text-center">
                      <img class="img-thumbnail img-responsive" src="img/prod/bully.jpg" alt="Image">
                      <div class="caption">
                        <h3 class="text-danger">BULLY </h3>
                        <p class="text-primary">7 DE 10<br>ACCION</p>
                        <p><button type="button" class="btn btn-success btn-sm">Más info</button></p>
                      </div>
                    </div>
                  </div>

                  <div class="col-sm-4">
                    <div class="thumbnail text-center">
                      <img class="img-thumbnail img-responsive" src="img/prod/virtua.jpg" alt="Image">
                      <div class="caption">
                        <h3 class="text-danger">VIRTUA TENNIS</h3>
                        <p class="text-primary">9 DE 10<br>DEPORTIVOS</p>
                        <p><button type="button" class="btn btn-success btn-sm">Más info</button></p>
                      </div>
                    </div>
                  </div>

            </div>
            
            <!--******ACCION*****-->
            <div class="tab-pane" id="accion">
                <div class="col-sm-6">
                    <div class="thumbnail text-center">
                      <img class="img-thumbnail img-responsive" src="img/prod/mw3.jpg" alt="Image">
                      <div class="caption">
                        <h3 class="text-danger">CALL OF DUTY MW3</h3>
                        <p class="text-primary">10 DE 10<br>FPS ACCION</p>
                        <p><button type="button" class="btn btn-success btn-sm">Más info</button></p>
                      </div>
                    </div>
                  </div>

                  <div class="col-sm-6">
                    <div class="thumbnail text-center">
                      <img class="img-thumbnail img-responsive" src="img/prod/gta.jpg" alt="Image">
                      <div class="caption">
                        <h3 class="text-danger">GTA V</h3>
                        <p class="text-primary">8 DE 10<br>ACCION</p>
                        <p><button type="button" class="btn btn-success btn-sm">Más info</button></p>
                      </div>
                    </div>
                  </div>
                
                <div class="col-sm-6">
                    <div class="thumbnail text-center">
                      <img class="img-thumbnail img-responsive" src="img/prod/prototype.jpg" alt="Image">
                      <div class="caption">
                        <h3 class="text-danger">PROTOTYPE</h3>
                        <p class="text-primary">10 DE 10<br>ACCION</p>
                        <p><button type="button" class="btn btn-success btn-sm">Más info</button></p>
                      </div>
                    </div>
                  </div>
                
                <div class="col-sm-6">
                    <div class="thumbnail text-center">
                      <img class="img-thumbnail img-responsive" src="img/prod/bully.jpg" alt="Image">
                      <div class="caption">
                        <h3 class="text-danger">BULLY!</h3>
                        <p class="text-primary">7 DE 10<br>ACCION</p>
                        <p><button type="button" class="btn btn-success btn-sm">Más info</button></p>
                      </div>
                    </div>
                  </div>
            </div>
            
            <!--*****DEPORTIVOS********-->
            <div class="tab-pane" id="deportivo">
                <div class="col-sm-4">
                    <div class="thumbnail text-center">
                      <img class="img-thumbnail img-responsive" src="img/prod/fifa.jpg" alt="Image">
                      <div class="caption">
                        <h3 class="text-danger">FIFA</h3>
                        <p class="text-primary">9 DE 10<br>DEPORTIVOS</p>
                        <p><button type="button" class="btn btn-success btn-sm">Más info</button></p>
                      </div>
                    </div>
                  </div>
                
                <div class="col-sm-4">
                    <div class="thumbnail text-center">
                      <img class="img-thumbnail img-responsive" src="img/prod/pes.jpg" alt="Image">
                      <div class="caption">
                        <h3 class="text-danger">PES</h3>
                        <p class="text-primary">9 DE 10<br>DEPORTIVOS</p>
                        <p><button type="button" class="btn btn-success btn-sm">Más info</button></p>
                      </div>
                    </div>
                  </div>

                  <div class="col-sm-4">
                    <div class="thumbnail text-center">
                      <img class="img-thumbnail img-responsive" src="img/prod/mlb.jpg" alt="Image">
                      <div class="caption">
                        <h3 class="text-danger">MLB THE SHOW</h3>
                        <p class="text-primary">10 DE 10<br>DEPORTIVOS</p>
                        <p><button type="button" class="btn btn-success btn-sm">Más info</button></p>
                      </div>
                    </div>
                  </div>
                
                <div class="col-sm-4">
                    <div class="thumbnail text-center">
                      <img class="img-thumbnail img-responsive" src="img/prod/virtua.jpg" alt="Image">
                      <div class="caption">
                        <h3 class="text-danger">VIRTUA TENNIS</h3>
                        <p class="text-primary">9 DE 10<br>DEPORTIVOS</p>
                        <p><button type="button" class="btn btn-success btn-sm">Más info</button></p>
                      </div>
                    </div>
                  </div>
                
               
                      </div>
                    </div>
                  </div>
            </div>
        </div>
      </div>
  </div>

  


  <div class="row">
    <div class="col-sm-12 text-center">
      <ul class="pagination">
        <li class="disabled"><a href="#">«</a></li>
        <li class="active"><a href="#">1 <span class="sr-only">(current)</span></a></li>
        
 
      </ul>
    </div>
  </div><!--fin row paginacion-->

</div><!--fin contenedor general-->